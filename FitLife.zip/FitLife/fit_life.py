# 1. Знакомство
user_name = input("Как тебя зовут? ")
user_age = input("Сколько тебе лет? ")
user_age = int(user_age)

# 2. Сбор данных
user_weight = input("Введите ваш вес в кг: ")
user_height = input("Введите ваш рост в метрах: ")
user_weight = float(user_weight)
user_height = float(user_height)


# расчёт индекса массы тела
bmi = user_weight / (user_height ** 2)
bmi_rounded = round(bmi, 1)

#Расчет кол-ва воды
water_ml = user_weight * 30
water_l = water_ml / 1000
water_l = int(water_l)

print(f"Привет, {user_name}! Твой возраст {user_age}.")
print(f"Твой индекс Массы Тела: {bmi_rounded}")
print(f"Рекомендуемая норма воды: {water_l:.1f} л. в день")

print("Расчет окончен. Будьте здоровы!")
